import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

const supabase=

createClient(

Deno.env.get(
"SUPABASE_URL"
)!,

Deno.env.get(
"SUPABASE_SERVICE_ROLE_KEY"
)!

)

const jwt=

req.headers.get(

"Authorization"

)

if(!jwt){

return new Response(

"Unauthorized",

{status:401}

)

}

const token=

jwt.replace(

"Bearer ",

""

)

const {

data:userData

}=await supabase

.auth

.getUser(token)

if(

!userData.user

){

return new Response(

"Unauthorized",

{status:401}

)

}

await supabase

.from(

"data_requests"

)

.insert({

user_id:

userData.user.id,

request_type:

"delete_account"

})

return Response.json({

success:true

})

})