import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

/*
==================================================
WORKER AUTHORIZATION
==================================================
*/

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

/*
==================================================
REQUEST BODY
==================================================
*/

const body = await req.json()

const {

environment,
region,
backupProvider,
checkType,
status

} = body

if(

!environment ||

!region ||

!backupProvider ||

!checkType

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
VALIDATION
==================================================
*/

if(

environment.length > 50 ||

region.length > 50 ||

backupProvider.length > 120 ||

checkType.length > 120

){

return new Response(

"Payload too large",

{

status:400

}

)

}

const allowedStatuses = [

"healthy",

"warning",

"critical"

]

if(

status &&

!allowedStatuses.includes(

status

)

){

return new Response(

"Invalid status",

{

status:400

}

)

}

/*
==================================================
SUPABASE CLIENT
==================================================
*/

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

/*
==================================================
TIMING
==================================================
*/

const startedAt = performance.now()

const checkedAt =

new Date()

.toISOString()

const latencyMs = Math.floor(

performance.now() - startedAt

)

/*
==================================================
INTEGRITY CHECK INSERT
==================================================
*/

await supabase

.from(

"system_integrity_checks"

)

.insert({

check_name:checkType,

status:

status || "healthy",

metadata:{

environment,
region,
backupProvider,
checkedAt,
latencyMs

}

})

/*
==================================================
BACKUP TELEMETRY
==================================================
*/

await supabase

.from(

"backup_health_events"

)

.insert({

environment,

region,

backup_provider:backupProvider,

check_type:checkType,

status:

status || "healthy",

latency_ms:latencyMs,

recorded_at:checkedAt

})

/*
==================================================
ALERTING
==================================================
*/

if(

status === "critical"

){

await supabase

.from(

"observability_events"

)

.insert({

service_name:"backup_system",

event_type:"backup_integrity_failure",

severity:"critical",

metadata:{

environment,
region,
backupProvider,
checkType

}

})

}

/*
==================================================
SYSTEM METRICS
==================================================
*/

await supabase

.from(

"system_metrics"

)

.insert({

metric_name:"backup_health_check",

metric_value:1,

metadata:{

environment,
region,
status:
status || "healthy"

}

})

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

ok:true,

status:

status || "healthy",

latencyMs

})

}

catch(error){

return new Response(

JSON.stringify({

ok:false,

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})