import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

const body = await req.json()

const {

triggerEvent,

entityType,

entityId,

payload

} = body

if(

!triggerEvent ||

!entityType ||

!entityId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const {

data:triggers,

error:triggerError

}

= await supabase

.from(

"automation_triggers"

)

.select("*")

.eq(

"enabled",

true

)

.eq(

"trigger_event",

triggerEvent

)

if(triggerError){

return new Response(

JSON.stringify({

error:triggerError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

for(

const trigger of triggers || []

){

await supabase

.from(

"automation_jobs"

)

.insert({

workflow_id:

trigger.workflow_id,

trigger_id:

trigger.id,

entity_type:

entityType,

entity_id:

entityId,

payload,

status:"pending"

})

}

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})