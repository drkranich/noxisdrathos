import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const ip = req.headers.get(

"x-forwarded-for"

)

const {

count,

error:countError

}

= await supabase

.from(

"rate_limits"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"user_id",

user.id

)

.gte(

"window_started",

new Date(

Date.now()-60000

).toISOString()

)

if(countError){

return new Response(

"Rate limit check failed",

{

status:500

}

)

}

if(

count &&

count > 120

){

await supabase

.from(

"security_incidents"

)

.insert({

severity:"high",

incident_type:"rate_limit",

user_id:user.id,

ip_address:ip

})

return new Response(

"Too many requests",

{

status:429

}

)

}

return Response.json({

allowed:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})