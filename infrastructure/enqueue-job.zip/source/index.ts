import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

const body = await req.json()

const {

queueName,

jobType,

payload,

priority

} = body

if(

!queueName ||

!jobType

){

return new Response(

"Missing fields",

{

status:400

}

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const {

error:insertError

}

= await supabase

.from(

"job_queue"

)

.insert({

queue_name:queueName,

job_type:jobType,

payload,

priority:priority || 5

})

if(insertError){

return new Response(

JSON.stringify({

error:insertError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})