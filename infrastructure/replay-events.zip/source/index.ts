import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      aggregate_type,
      aggregate_id
    } = body;

    const { data: events, error } = await supabase
      .from("event_store")
      .select("*")
      .eq("aggregate_type", aggregate_type)
      .eq("aggregate_id", aggregate_id)
      .order("created_at", {
        ascending: true
      });

    if (error) {
      throw error;
    }

    return Response.json({

      success: true,

      aggregate_type,

      aggregate_id,

      total_events: events?.length || 0,

      events

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {
      status: 500
    });

  }

});