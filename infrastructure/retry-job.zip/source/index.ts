import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const { scheduled_job_id } = body;

    const { data: job, error: jobError } = await supabase
      .from("scheduled_jobs")
      .select("*")
      .eq("id", scheduled_job_id)
      .single();

    if (jobError || !job) {

      return Response.json({
        success: false,
        error: "job_not_found"
      }, {
        status: 404
      });

    }

    await supabase
      .from("job_retries")
      .insert({

        scheduled_job_id,

        retry_count: 1,

        retry_reason: "manual_retry"

      });

    await supabase
      .from("scheduled_jobs")
      .update({

        status: "pending",

        executed_at: null

      })
      .eq("id", scheduled_job_id);

    return Response.json({

      success: true,

      retried_job: scheduled_job_id

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});