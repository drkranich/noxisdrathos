import "jsr:@supabase/functions-js/edge-runtime.d.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js@2"

Deno.serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

JSON.stringify({

error:"Missing token"

}),

{

status:401,

headers:{

"Content-Type":

"application/json"

}

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

} = await supabase.auth.getUser()

if(userError || !user){

return new Response(

JSON.stringify({

error:"Invalid user"

}),

{

status:401,

headers:{

"Content-Type":

"application/json"

}

}

)

}

const body = await req.json()

const filePath = body.filePath

if(!filePath){

return new Response(

JSON.stringify({

error:"Missing filePath"

}),

{

status:400,

headers:{

"Content-Type":

"application/json"

}

}

)

}

const {

data:subscription

} = await supabase

.from("subscriptions")

.select("status")

.eq(

"user_id",

user.id

)

.single()

if(

!subscription ||

subscription.status !== "active"

){

return new Response(

JSON.stringify({

error:"Premium required"

}),

{

status:403,

headers:{

"Content-Type":

"application/json"

}

}

)

}

const serviceSupabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const {

data,

error

} = await serviceSupabase

.storage

.from("premium-content")

.createSignedUrl(

filePath,

60

)

if(error){

return new Response(

JSON.stringify({

error:error.message

}),

{

status:400,

headers:{

"Content-Type":

"application/json"

}

}

)

}

return new Response(

JSON.stringify({

signedUrl:data.signedUrl

}),

{

headers:{

"Content-Type":

"application/json"

}

}

)

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})