import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const { data: policies } = await supabase
      .from("data_retention_policies")
      .select("*")
      .eq("enabled", true);

    return Response.json({

      success: true,

      active_policies:
        policies?.length || 0,

      policies:
        policies || []

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});