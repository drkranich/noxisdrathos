import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      incident_id
    } = body;

    const { data: incident, error } = await supabase
      .from("security_incidents")
      .select("*")
      .eq("id", incident_id)
      .single();

    if (error || !incident) {

      return Response.json({
        success: false,
        error: "incident_not_found"
      }, {
        status: 404
      });

    }

    await supabase
      .from("security_incidents")
      .update({
        resolved: true
      })
      .eq("id", incident_id);

    return Response.json({

      success: true,

      incident_id,

      previous_severity:
        incident.severity,

      status:
        "resolved"

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {
      status: 500
    });

  }

});