import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const body = await req.json()

const {

targetUserId,
eventType,
tenantId,
entityId

} = body

if(

!targetUserId ||

!eventType ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
ALLOWED EVENTS
==================================================
*/

const scoreMap = {

comment_created:5,

post_created:10,

answer_accepted:25,

daily_login:1,

content_shared:8,

helpful_vote:3,

course_completed:20

}

const points = scoreMap[eventType]

if(!points){

return new Response(

"Invalid event type",

{

status:400

}

)

}

/*
==================================================
ANTI FARMING
==================================================
*/

const {

count:recentEvents

}

= await supabase

.from(

"community_score_events"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"actor_user_id",

user.id

)

.eq(

"event_type",

eventType

)

.gte(

"created_at",

new Date(

Date.now()-60000

).toISOString()

)

if(

recentEvents &&

recentEvents > 20

){

return new Response(

"Rate limited",

{

status:429

}

)

}

/*
==================================================
DEDUPLICATION
==================================================
*/

if(entityId){

const {

data:existing

}

= await supabase

.from(

"community_score_events"

)

.select(`

id

`)

.eq(

"actor_user_id",

user.id

)

.eq(

"event_type",

eventType

)

.eq(

"entity_id",

entityId

)

.maybeSingle()

if(existing){

return Response.json({

ok:true,

deduplicated:true

})

}

}

/*
==================================================
INCREMENT REPUTATION
==================================================
*/

const {

error:rpcError

}

= await supabase.rpc(

"increment_reputation",

{

target_user:targetUserId,

points

}

)

if(rpcError){

return new Response(

JSON.stringify({

error:rpcError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

/*
==================================================
AUDIT EVENT
==================================================
*/

await supabase

.from(

"community_score_events"

)

.insert({

tenant_id:tenantId,

actor_user_id:user.id,

target_user_id:targetUserId,

event_type:eventType,

entity_id:entityId,

points_awarded:points

})

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

ok:true,

pointsAwarded:points

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})