import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const startedAt = Date.now();

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const latency =
      Date.now() - startedAt;

    await supabase
      .from("service_health")
      .insert({

        service_name: "supabase-core",

        status: "healthy",

        latency_ms: latency,

        metadata: {
          check_type: "heartbeat"
        }

      });

    return Response.json({

      success: true,

      service: "supabase-core",

      status: "healthy",

      latency_ms: latency

    });

  } catch (error) {

    await supabase
      .from("error_events")
      .insert({

        service_name: "service-health-check",

        error_type: "health_check_failure",

        error_message: String(error)

      });

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});