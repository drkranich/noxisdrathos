import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const {

count:users

}

= await supabase

.from("profiles")

.select(

"*",

{

count:"exact",

head:true

}

)

const {

count:subscriptions

}

= await supabase

.from("subscriptions")

.select(

"*",

{

count:"exact",

head:true

}

)

const {

count:content

}

= await supabase

.from("content")

.select(

"*",

{

count:"exact",

head:true

}

)

const {

count:comments

}

= await supabase

.from("comments")

.select(

"*",

{

count:"exact",

head:true

}

)

await supabase

.from(

"platform_snapshots"

)

.insert({

users_count:users,

subscriptions_count:subscriptions,

content_count:content,

comments_count:comments

})

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})