import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {

      user_id,
      resource_type,
      action_type

    } = body;

    const { data: policies, error } = await supabase
      .from("access_policies")
      .select("*")
      .eq("resource_type", resource_type)
      .eq("action_type", action_type)
      .eq("enabled", true);

    if (error) {
      throw error;
    }

    let decision = "deny";
    let reason = "no_matching_policy";
    let policyId = null;

    if ((policies || []).length > 0) {

      const matchedPolicy = policies[0];

      decision = matchedPolicy.effect;
      reason = matchedPolicy.policy_name;
      policyId = matchedPolicy.id;

    }

    await supabase
      .from("policy_decisions")
      .insert({

        policy_id: policyId,

        user_id,

        resource_type,

        action_type,

        decision,

        decision_reason: reason

      });

    await supabase
      .from("policy_audit_logs")
      .insert({

        policy_name: reason,

        user_id,

        resource_type,

        action_type,

        result: decision,

        metadata: {}

      });

    return Response.json({

      success: true,

      decision,

      reason

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});