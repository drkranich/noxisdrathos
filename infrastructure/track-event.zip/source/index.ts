import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"No user",

{

status:401

}

)

}

const body = await req.json()

const {

eventName,
entityType,
entityId,
metadata,
sessionId,
tenantId

} = body

if(

!eventName ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
ALLOWED EVENTS
==================================================
*/

const allowedEvents = [

"page_view",

"video_start",

"video_complete",

"content_open",

"comment_created",

"search_executed",

"purchase_started",

"purchase_completed"

]

if(

!allowedEvents.includes(

eventName

)

){

return new Response(

"Invalid event",

{

status:400

}

)

}

/*
==================================================
SAFE ENTITY TYPES
==================================================
*/

const allowedEntities = [

"content",

"video",

"comment",

"search",

"purchase"

]

if(

entityType &&

!allowedEntities.includes(

entityType

)

){

return new Response(

"Invalid entity",

{

status:400

}

)

}

/*
==================================================
SAFE METADATA
==================================================
*/

const safeMetadata =

metadata || {}

const metadataString =

JSON.stringify(

safeMetadata

)

if(

metadataString.length > 5000

){

return new Response(

"Metadata too large",

{

status:400

}

)

}

/*
==================================================
ANTI FLOOD
==================================================
*/

const {

count:recentEvents

}

= await supabase

.from(

"analytics_events"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"user_id",

user.id

)

.gte(

"created_at",

new Date(

Date.now()-60000

).toISOString()

)

if(

recentEvents &&

recentEvents > 300

){

return new Response(

"Rate limited",

{

status:429

}

)

}

/*
==================================================
DEDUPLICATION
==================================================
*/

if(

eventName === "purchase_completed"

){

const {

data:existing

}

= await supabase

.from(

"analytics_events"

)

.select(`

id

`)

.eq(

"user_id",

user.id

)

.eq(

"event_name",

eventName

)

.eq(

"entity_id",

entityId

)

.gte(

"created_at",

new Date(

Date.now()-300000

).toISOString()

)

.maybeSingle()

if(existing){

return Response.json({

ok:true,

deduplicated:true

})

}

}

/*
==================================================
FORENSIC CONTEXT
==================================================
*/

const rawIp = req.headers.get(

"x-forwarded-for"

) || ""

const ipAddress = rawIp

.split(",")

[0]

.trim()

const userAgent =

req.headers.get(

"user-agent"

) || null

/*
==================================================
INSERT EVENT
==================================================
*/

await supabase

.from(

"analytics_events"

)

.insert({

tenant_id:tenantId,

user_id:user.id,

event_name:eventName,

entity_type:entityType,

entity_id:entityId,

metadata:safeMetadata,

session_id:sessionId,

ip_address:ipAddress,

user_agent:userAgent

})

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})