import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

/*
==================================================
WORKER AUTHORIZATION
==================================================
*/

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

/*
==================================================
REQUEST START
==================================================
*/

const startedAt = performance.now()

/*
==================================================
REQUEST BODY
==================================================
*/

const body = await req.json()

const {

serviceName,
environment,
region,
status

} = body

if(

!serviceName ||

!environment ||

!region

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
VALIDATION
==================================================
*/

if(

serviceName.length > 120 ||

environment.length > 50 ||

region.length > 50

){

return new Response(

"Payload too large",

{

status:400

}

)

}

const allowedStatuses = [

"healthy",

"degraded",

"unhealthy"

]

if(

status &&

!allowedStatuses.includes(

status

)

){

return new Response(

"Invalid status",

{

status:400

}

)

}

/*
==================================================
SUPABASE CLIENT
==================================================
*/

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

/*
==================================================
LATENCY
==================================================
*/

const latencyMs = Math.floor(

performance.now() - startedAt

)

/*
==================================================
HEALTH INSERT
==================================================
*/

await supabase

.from(

"service_health"

)

.insert({

service_name:serviceName,

environment,

region,

status:

status || "healthy",

latency_ms:latencyMs,

recorded_at:

new Date()

.toISOString()

})

/*
==================================================
SYSTEM METRICS
==================================================
*/

await supabase

.from(

"system_metrics"

)

.insert({

metric_name:"heartbeat",

metric_value:1,

metadata:{

serviceName,
environment,
region,
latencyMs

}

})

/*
==================================================
OBSERVABILITY AUDIT
==================================================
*/

await supabase

.from(

"observability_events"

)

.insert({

service_name:serviceName,

event_type:"heartbeat",

severity:

latencyMs > 1000

? "warning"

: "info",

metadata:{

environment,
region,
latencyMs

}

})

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

healthy:true,

latencyMs

})

}

catch(error){

return new Response(

JSON.stringify({

healthy:false,

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})