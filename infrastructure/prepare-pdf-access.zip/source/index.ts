import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"No user",

{

status:401

}

)

}

const body = await req.json()

const {

path

} = body

if(!path){

return new Response(

"Missing path",

{

status:400

}

)

}

const {

data:subscription

}

= await supabase

.from(

"subscriptions"

)

.select(

"status"

)

.eq(

"user_id",

user.id

)

.eq(

"status",

"active"

)

.single()

if(!subscription){

return new Response(

"No subscription",

{

status:403

}

)

}

await supabase

.from(

"pdf_watermarks"

)

.insert({

user_id:user.id,

file_path:path,

watermark_text:

`${user.email}

${new Date().toISOString()}`

})

const serviceSupabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const {

data,

error

}

= await serviceSupabase

.storage

.from(

"pdfs"

)

.createSignedUrl(

path,

300

)

if(error){

return new Response(

JSON.stringify({

error:error.message

}),

{

status:400,

headers:{

"Content-Type":

"application/json"

}

}

)

}

return Response.json(data)

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})