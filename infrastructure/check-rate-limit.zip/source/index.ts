import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const body = await req.json().catch(() => ({}));

  const ip =
    body.ip ||
    req.headers.get("x-forwarded-for") ||
    "unknown";

  const endpoint =
    body.endpoint ||
    "default";

  const blocked = await supabase
    .from("blocked_ips")
    .select("id")
    .eq("ip_address", ip)
    .maybeSingle();

  if (blocked.data) {

    return Response.json({
      allowed: false,
      reason: "blocked"
    }, {
      status: 429
    });

  }

  const oneMinuteAgo = new Date(
    Date.now() - 60000
  ).toISOString();

  const { count } = await supabase
    .from("request_counters")
    .select("*", {
      count: "exact",
      head: true
    })
    .eq("ip_address", ip)
    .eq("endpoint", endpoint)
    .gte("created_at", oneMinuteAgo);

  const requests = count ?? 0;

  if (requests >= 100) {

    await supabase
      .from("abuse_events")
      .insert({
        ip_address: ip,
        endpoint,
        event_type: "rate_limit_exceeded"
      });

    return Response.json({
      allowed: false,
      reason: "rate_limit_exceeded"
    }, {
      status: 429
    });

  }

  await supabase
    .from("request_counters")
    .insert({
      ip_address: ip,
      endpoint,
      request_count: 1,
      window_start: new Date().toISOString()
    });

  return Response.json({
    allowed: true,
    current_requests: requests + 1,
    limit: 100
  });

});