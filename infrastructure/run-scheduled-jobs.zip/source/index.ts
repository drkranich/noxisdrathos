import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(

    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!

  );

  try {

    const now = new Date().toISOString();

    const { data: jobs, error } = await supabase

      .from("scheduled_jobs")

      .select("*")

      .eq("status", "pending")

      .lte("scheduled_for", now);

    if (error) {

      throw error;

    }

    const results = [];

    for (const job of jobs || []) {

      try {

        await supabase

          .from("job_executions")

          .insert({

            scheduled_job_id: job.id,

            execution_status: "started",

            started_at: now

          });

        await supabase

          .from("scheduled_jobs")

          .update({

            status: "completed",

            executed_at: now

          })

          .eq("id", job.id);

        await supabase

          .from("job_executions")

          .insert({

            scheduled_job_id: job.id,

            execution_status: "completed",

            started_at: now,

            finished_at: now,

            execution_log: {

              payload: job.payload_json

            }

          });

        results.push({

          job_id: job.id,

          status: "completed"

        });

      } catch (jobError) {

        await supabase

          .from("dead_letter_jobs")

          .insert({

            job_name: job.job_type,

            edge_function:

              job.payload_json?.edge_function ||

              "unknown",

            payload: job.payload_json,

            failure_reason: String(jobError)

          });

        results.push({

          job_id: job.id,

          status: "failed"

        });

      }

    }

    return Response.json({

      success: true,

      processed_jobs: results.length,

      results

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});