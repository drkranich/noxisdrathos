import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      user_id,
      consent_type,
      consent_version
    } = body;

    const { data, error } = await supabase
      .from("consent_records")
      .insert({

        user_id,

        consent_type,

        consent_version,

        granted: true,

        granted_at:
          new Date().toISOString()

      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return Response.json({

      success: true,

      consent_id: data.id,

      consent_type,

      consent_version,

      granted: true

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});