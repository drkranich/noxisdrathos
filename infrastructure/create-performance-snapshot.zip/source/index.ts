import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const { data: metrics } = await supabase
      .from("system_metrics")
      .select("*")
      .order("collected_at", {
        ascending: false
      })
      .limit(100);

    const snapshot = {

      total_metrics:
        metrics?.length || 0,

      generated_at:
        new Date().toISOString(),

      metrics

    };

    await supabase
      .from("performance_snapshots")
      .insert({

        snapshot_name:
          "observability_snapshot",

        metrics: snapshot

      });

    return Response.json({

      success: true,

      total_metrics:
        metrics?.length || 0

    });

  } catch (error) {

    await supabase
      .from("error_events")
      .insert({

        service_name:
          "create-performance-snapshot",

        error_type:
          "snapshot_failure",

        error_message:
          String(error)

      });

    return Response.json({

      success: false,

      error:
        String(error)

    }, {

      status: 500

    });

  }

});