import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const {

data:jobs,

error:jobsError

}

= await supabase

.from(

"ai_jobs"

)

.select("*")

.eq(

"status",

"pending"

)

.limit(10)

if(jobsError){

return new Response(

JSON.stringify({

error:jobsError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

for(

const job of jobs || []

){

await supabase

.from(

"ai_jobs"

)

.update({

status:"processing",

started_at:

new Date()

})

.eq(

"id",

job.id

)

}

return Response.json({

processed:

jobs?.length || 0

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})