import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

const body = await req.json()

const {

contentId,

tags

} = body

if(

!contentId ||

!Array.isArray(tags)

){

return new Response(

"Invalid payload",

{

status:400

}

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

for(

const tag of tags

){

await supabase

.from(

"ai_content_tags"

)

.insert({

content_id:contentId,

tag:tag.name,

confidence:tag.score

})

}

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})