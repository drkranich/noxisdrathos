import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const body = await req.json()

const {

cacheKey,
group,
tenantId

} = body

if(

!cacheKey ||

!group ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
PAYLOAD VALIDATION
==================================================
*/

if(

cacheKey.length > 255 ||

group.length > 120

){

return new Response(

"Payload too large",

{

status:400

}

)

}

/*
==================================================
SAFE GROUPS
==================================================
*/

const allowedGroups = [

"content",

"search",

"recommendations",

"analytics",

"user_dashboard"

]

if(

!allowedGroups.includes(

group

)

){

return new Response(

"Invalid group",

{

status:400

}

)

}

/*
==================================================
ANTI ENUMERATION
==================================================
*/

const {

count:recentRequests

}

= await supabase

.from(

"cache_access_logs"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"user_id",

user.id

)

.gte(

"created_at",

new Date(

Date.now()-60000

).toISOString()

)

if(

recentRequests &&

recentRequests > 300

){

return new Response(

"Rate limited",

{

status:429

}

)

}

/*
==================================================
FETCH CACHE ENTRY
==================================================
*/

const {

data:cacheEntry,

error:cacheError

}

= await supabase

.from(

"cache_entries"

)

.select(`

cache_value,
expires_at,
hit_count

`)

.eq(

"tenant_id",

tenantId

)

.eq(

"group_name",

group

)

.eq(

"cache_key",

cacheKey

)

.gt(

"expires_at",

new Date()

.toISOString()

)

.maybeSingle()

if(cacheError){

return new Response(

JSON.stringify({

error:cacheError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

/*
==================================================
CACHE HIT
==================================================
*/

if(cacheEntry){

await supabase.rpc(

"increment_cache_hit",

{

cache_key:cacheKey

}

)

/*
-----------------------------------
ACCESS LOG
-----------------------------------
*/

await supabase

.from(

"cache_access_logs"

)

.insert({

tenant_id:tenantId,

user_id:user.id,

cache_key:cacheKey,

group_name:group,

cache_hit:true

})

return Response.json({

cached:true,

data:

cacheEntry.cache_value,

expiresAt:

cacheEntry.expires_at

})

}

/*
==================================================
CACHE MISS LOG
==================================================
*/

await supabase

.from(

"cache_access_logs"

)

.insert({

tenant_id:tenantId,

user_id:user.id,

cache_key:cacheKey,

group_name:group,

cache_hit:false

})

/*
==================================================
CACHE MISS RESPONSE
==================================================
*/

return Response.json({

cached:false

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})