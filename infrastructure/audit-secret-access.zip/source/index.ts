import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(

    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!

  );

  try {

    const body = await req.json();

    const {

      secret_name,
      function_name,
      access_type,
      metadata

    } = body;

    await supabase

      .from("secret_audit_logs")

      .insert({

        secret_name,

        function_name,

        access_type,

        metadata: metadata || {}

      });

    await supabase

      .from("secret_access_logs")

      .insert({

        secret_name,

        function_name,

        access_status: "success",

        metadata: metadata || {}

      });

    return Response.json({

      success: true

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});