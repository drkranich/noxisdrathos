import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const { data: contents } = await supabase
      .from("content")
      .select("*");

    let refreshed = 0;

    for (const item of contents || []) {

      await supabase
        .from("content_read_models")
        .update({

          title: item.title,

          content_type: item.content_type,

          visibility: item.visibility,

          access_level: item.access_level,

          published: item.published,

          published_at: item.published_at,

          projection_version: 2,

          updated_at: new Date().toISOString()

        })
        .eq("content_id", item.id);

      refreshed++;

    }

    return Response.json({

      success: true,

      refreshed

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});