import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"No user",

{

status:401

}

)

}

const body = await req.json()

const {

filePath

} = body

if(

!filePath ||

typeof filePath !== "string"

){

return new Response(

"Invalid path",

{

status:400

}

)

}

if(filePath.length > 500){

return new Response(

"Path too large",

{

status:400

}

)

}

const allowedPrefixes = [

"premium-content/",

"ebooks/",

"videos/"

]

const validPrefix = allowedPrefixes.some(

prefix => filePath.startsWith(prefix)

)

if(!validPrefix){

return new Response(

"Invalid file path",

{

status:403

}

)

}

if(

filePath.includes("..")

){

return new Response(

"Invalid path",

{

status:400

}

)

}

const maskedEmail =

user.email

?.replace(

/(.{2}).+(@.+)/,

"$1***$2"

)

const watermark =

`${user.id}

${user.email}

${Date.now()}`

const hash = await crypto.subtle.digest(

"SHA-256",

new TextEncoder().encode(

watermark

)

)

const hashHex =

Array

.from(

new Uint8Array(hash)

)

.map(

b =>

b.toString(16)

.padStart(2,"0")

)

.join("")

await supabase

.from(

"dynamic_watermarks"

)

.insert({

user_id:user.id,

file_path:filePath,

watermark_hash:hashHex,

visible_watermark:

`Licensed to ${maskedEmail}`,

invisible_watermark:hashHex

})

return Response.json({

success:true,

watermark:hashHex

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})