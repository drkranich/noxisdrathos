import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      job_type,
      payload_json,
      scheduled_for
    } = body;

    const { data, error } = await supabase
      .from("scheduled_jobs")
      .insert({

        job_type,

        payload_json: payload_json || {},

        status: "pending",

        scheduled_for:
          scheduled_for ||
          new Date().toISOString()

      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return Response.json({

      success: true,

      job_id: data.id,

      status: data.status

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});