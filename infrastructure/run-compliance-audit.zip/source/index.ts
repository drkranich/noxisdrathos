import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const findings: string[] = [];

    const { count: retentionPolicies } = await supabase
      .from("data_retention_policies")
      .select("*", {
        count: "exact",
        head: true
      });

    if ((retentionPolicies || 0) === 0) {
      findings.push(
        "No retention policies configured"
      );
    }

    const { count: consentRecords } = await supabase
      .from("consent_records")
      .select("*", {
        count: "exact",
        head: true
      });

    if ((consentRecords || 0) === 0) {
      findings.push(
        "No consent records found"
      );
    }

    const auditStatus =
      findings.length === 0
        ? "passed"
        : "warning";

    const { data, error } = await supabase
      .from("compliance_audits")
      .insert({

        audit_name:
          "automatic_compliance_audit",

        audit_status:
          auditStatus,

        findings,

        executed_at:
          new Date().toISOString()

      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return Response.json({

      success: true,

      audit_id: data.id,

      audit_status: auditStatus,

      findings

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});