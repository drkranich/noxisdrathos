import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      hold_name,
      resource_type,
      resource_id,
      reason
    } = body;

    const { data, error } = await supabase
      .from("legal_holds")
      .insert({

        hold_name,

        resource_type,

        resource_id,

        reason,

        active: true

      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return Response.json({

      success: true,

      legal_hold_id: data.id,

      active: true

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});