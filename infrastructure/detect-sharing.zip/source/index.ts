import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"No user",

{

status:401

}

)

}

const body = await req.json()

const {

fingerprint,

country,

city,

sessionId

} = body

if(

!fingerprint ||

!sessionId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

if(

fingerprint.length > 255 ||

country?.length > 100 ||

city?.length > 100 ||

sessionId.length > 255

){

return new Response(

"Payload too large",

{

status:400

}

)

}

const rawIp = req.headers.get(

"x-forwarded-for"

) || ""

const ip = rawIp

.split(",")

[0]

.trim()

const {

count:recentCount

}

= await supabase

.from(

"concurrent_access_events"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"user_id",

user.id

)

.gte(

"created_at",

new Date(

Date.now()-60000

).toISOString()

)

if(

recentCount &&

recentCount > 30

){

return new Response(

"Too many requests",

{

status:429

}

)

}

await supabase

.from(

"concurrent_access_events"

)

.insert({

user_id:user.id,

fingerprint,

country,

city,

session_id:sessionId,

ip_address:ip

})

const {

count

}

= await supabase

.from(

"concurrent_access_events"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"user_id",

user.id

)

.gte(

"created_at",

new Date(

Date.now()-900000

).toISOString()

)

if(

count &&

count > 6

){

await supabase

.from(

"security_actions"

)

.insert({

user_id:user.id,

action_type:

"share_detected",

reason:

"too_many_sessions"

})

}

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})