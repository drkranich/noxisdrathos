import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"No user",

{

status:401

}

)

}

const body = await req.json()

const {

actionType,
entityType,
entityId,
metadata,
tenantId

} = body

if(

!actionType ||

!entityType ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
ALLOWED ACTIONS
==================================================
*/

const allowedActions = [

"profile_updated",

"password_changed",

"content_created",

"content_updated",

"comment_created",

"subscription_updated",

"video_started",

"video_completed"

]

if(

!allowedActions.includes(

actionType

)

){

return new Response(

"Invalid action",

{

status:400

}

)

}

/*
==================================================
SAFE ENTITY TYPES
==================================================
*/

const allowedEntities = [

"profile",

"content",

"comment",

"subscription",

"video"

]

if(

!allowedEntities.includes(

entityType

)

){

return new Response(

"Invalid entity",

{

status:400

}

)

}

/*
==================================================
METADATA SANITIZATION
==================================================
*/

const safeMetadata =

metadata || {}

const metadataString =

JSON.stringify(

safeMetadata

)

if(

metadataString.length > 5000

){

return new Response(

"Metadata too large",

{

status:400

}

)

}

/*
==================================================
ANTI FLOOD
==================================================
*/

const {

count:recentLogs

}

= await supabase

.from(

"audit_logs"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"actor_user_id",

user.id

)

.gte(

"created_at",

new Date(

Date.now()-60000

).toISOString()

)

if(

recentLogs &&

recentLogs > 100

){

return new Response(

"Rate limited",

{

status:429

}

)

}

/*
==================================================
FORENSIC CONTEXT
==================================================
*/

const rawIp = req.headers.get(

"x-forwarded-for"

) || ""

const ipAddress = rawIp

.split(",")

[0]

.trim()

const userAgent =

req.headers.get(

"user-agent"

) || null

/*
==================================================
INSERT AUDIT LOG
==================================================
*/

await supabase

.from(

"audit_logs"

)

.insert({

tenant_id:tenantId,

actor_user_id:user.id,

action_type:actionType,

entity_type:entityType,

entity_id:entityId,

metadata:safeMetadata,

ip_address:ipAddress,

user_agent:userAgent

})

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

success:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})