import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      resource_type,
      action_type
    } = body;

    const { data: policies, error } = await supabase
      .from("access_policies")
      .select("*")
      .eq("resource_type", resource_type)
      .eq("action_type", action_type)
      .eq("enabled", true);

    if (error) {
      throw error;
    }

    return Response.json({

      success: true,

      simulation: {

        resource_type,

        action_type,

        matching_policies: policies?.length || 0,

        policies

      }

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});