import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const startedAt = Date.now();

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const { count: pendingJobs } = await supabase
      .from("scheduled_jobs")
      .select("*", {
        count: "exact",
        head: true
      })
      .eq("status", "pending");

    const { count: failedJobs } = await supabase
      .from("dead_letter_jobs")
      .select("*", {
        count: "exact",
        head: true
      });

    const { count: totalPolicies } = await supabase
      .from("access_policies")
      .select("*", {
        count: "exact",
        head: true
      });

    const executionTime =
      Date.now() - startedAt;

    await supabase
      .from("system_metrics")
      .insert([

        {
          metric_name: "pending_jobs",
          metric_value: pendingJobs || 0,
          labels: {
            source: "scheduler"
          }
        },

        {
          metric_name: "failed_jobs",
          metric_value: failedJobs || 0,
          labels: {
            source: "queue"
          }
        },

        {
          metric_name: "active_policies",
          metric_value: totalPolicies || 0,
          labels: {
            source: "policy_engine"
          }
        },

        {
          metric_name: "collection_time_ms",
          metric_value: executionTime,
          labels: {
            source: "observability"
          }
        }

      ]);

    return Response.json({

      success: true,

      pending_jobs: pendingJobs || 0,

      failed_jobs: failedJobs || 0,

      active_policies: totalPolicies || 0,

      collection_time_ms: executionTime

    });

  } catch (error) {

    await supabase
      .from("error_events")
      .insert({

        service_name: "collect-system-metrics",

        error_type: "runtime_error",

        error_message: String(error)

      });

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});