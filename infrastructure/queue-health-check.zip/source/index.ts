import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const { count: pendingJobs } = await supabase
      .from("scheduled_jobs")
      .select("*", {
        count: "exact",
        head: true
      })
      .eq("status", "pending");

    const { count: processingJobs } = await supabase
      .from("queue_workers")
      .select("*", {
        count: "exact",
        head: true
      })
      .eq("status", "processing");

    const { count: failedJobs } = await supabase
      .from("dead_letter_jobs")
      .select("*", {
        count: "exact",
        head: true
      });

    await supabase
      .from("queue_metrics")
      .insert({

        queue_name: "default",

        pending_count: pendingJobs || 0,

        processing_count: processingJobs || 0,

        failed_count: failedJobs || 0,

        average_ms: 0,

        snapshot_at: new Date().toISOString()

      });

    return Response.json({

      success: true,

      pending_jobs: pendingJobs || 0,

      processing_jobs: processingJobs || 0,

      failed_jobs: failedJobs || 0

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});