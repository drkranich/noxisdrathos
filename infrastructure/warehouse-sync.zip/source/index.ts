import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const {

data:analytics,

error:analyticsError

}

= await supabase

.from(

"analytics_events"

)

.select("*")

.limit(1000)

if(analyticsError){

return new Response(

JSON.stringify({

error:analyticsError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

for(

const row of analytics || []

){

await supabase

.from(

"dw_user_activity_fact"

)

.insert({

user_id:row.user_id,

activity_type:row.event_name,

entity_type:row.entity_type,

entity_id:row.entity_id,

occurred_at:row.created_at

})

}

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})