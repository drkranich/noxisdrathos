import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const body = await req.json()

const {

fingerprint,
browser,
os,
tenantId

} = body

if(

!fingerprint ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
PAYLOAD VALIDATION
==================================================
*/

if(

fingerprint.length > 255 ||

browser?.length > 120 ||

os?.length > 120

){

return new Response(

"Payload too large",

{

status:400

}

)

}

/*
==================================================
ANTI FLOOD
==================================================
*/

const {

count:recentLogs

}

= await supabase

.from(

"login_audit"

)

.select(

"*",

{

count:"exact",

head:true

}

)

.eq(

"user_id",

user.id

)

.gte(

"created_at",

new Date(

Date.now()-60000

).toISOString()

)

if(

recentLogs &&

recentLogs > 60

){

return new Response(

"Rate limited",

{

status:429

}

)

}

/*
==================================================
IP NORMALIZATION
==================================================
*/

const rawIp = req.headers.get(

"x-forwarded-for"

) || ""

const ipAddress = rawIp

.split(",")

[0]

.trim()

/*
==================================================
USER AGENT
==================================================
*/

const userAgent =

req.headers.get(

"user-agent"

) || null

/*
==================================================
RISK SCORE
==================================================
*/

let riskScore = 0

if(

fingerprint.length < 10

){

riskScore += 25

}

if(

!browser ||

!os

){

riskScore += 15

}

if(

rawIp.includes(",")

){

riskScore += 10

}

/*
==================================================
AUDIT LOGIN
==================================================
*/

await supabase

.from(

"login_audit"

)

.insert({

tenant_id:tenantId,

user_id:user.id,

ip_address:ipAddress,

browser,

operating_system:os,

device_fingerprint:fingerprint,

user_agent:userAgent,

risk_score:riskScore,

success:true

})

/*
==================================================
SAFE DEVICE UPSERT
==================================================
*/

await supabase

.from(

"user_devices"

)

.upsert({

tenant_id:tenantId,

user_id:user.id,

fingerprint,

browser,

operating_system:os,

ip_address:ipAddress,

risk_score:riskScore,

last_seen:

new Date()

.toISOString()

},

{

onConflict:

"user_id,fingerprint"

})

/*
==================================================
HIGH RISK ALERT
==================================================
*/

if(

riskScore >= 30

){

await supabase

.from(

"security_incidents"

)

.insert({

tenant_id:tenantId,

user_id:user.id,

severity:"medium",

incident_type:

"suspicious_device",

metadata:{

fingerprint,

browser,

os,

riskScore

}

})

}

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

ok:true,

riskScore

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})