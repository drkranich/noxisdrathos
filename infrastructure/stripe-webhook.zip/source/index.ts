import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

import Stripe

from "https://esm.sh/stripe@14.25.0"

const stripe = new Stripe(

Deno.env.get("STRIPE_SECRET_KEY")!,

{

apiVersion:"2023-10-16"

}

)

serve(async(req)=>{

const signature = req.headers.get(

"stripe-signature"

)

if(!signature){

return new Response(

"Missing stripe signature",

{ status:400 }

)

}

const body = await req.text()

let event

try{

event = stripe.webhooks.constructEvent(

body,

signature,

Deno.env.get(

"STRIPE_WEBHOOK_SECRET"

)!

)

}catch(err){

return new Response(

`Webhook Error: ${err.message}`,

{ status:400 }

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

switch(event.type){

case "checkout.session.completed":{

const session = event.data.object

const userId = session.metadata?.userId

if(!userId){

return new Response(

"Missing userId metadata",

{ status:400 }

)

}

await supabase

.from("subscriptions")

.update({

status:"active"

})

.eq(

"user_id",

userId

)

break

}

case "customer.subscription.deleted":{

const subscription = event.data.object

const userId = subscription.metadata?.userId

if(!userId){

return new Response(

"Missing userId metadata",

{ status:400 }

)

}

await supabase

.from("subscriptions")

.update({

status:"cancelled"

})

.eq(

"user_id",

userId

)

break

}

}

return Response.json({

received:true

})

})