import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"No user",

{

status:401

}

)

}

const {

data:history,

error:historyError

}

= await supabase

.from(

"watch_history"

)

.select(

"content_id"

)

.eq(

"user_id",

user.id

)

.limit(10)

if(historyError){

return new Response(

JSON.stringify({

error:historyError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

const ids =

history?.map(

x=>x.content_id

) || []

if(ids.length === 0){

return Response.json({

recommendations:[]

})

}

const {

data:recommendations,

error:recommendationError

}

= await supabase

.from(

"content_similarity"

)

.select(`

recommended_content_id,

similarity_score,

reason

`)

.in(

"source_content_id",

ids

)

.order(

"similarity_score",

{

ascending:false

}

)

.limit(30)

if(recommendationError){

return new Response(

JSON.stringify({

error:recommendationError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

return Response.json({

recommendations

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})