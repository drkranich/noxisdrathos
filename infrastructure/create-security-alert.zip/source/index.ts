import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      user_id,
      alert_type,
      severity,
      description,
      metadata
    } = body;

    const alertInsert = await supabase
      .from("security_alerts")
      .insert({
        user_id,
        alert_type,
        severity,
        description,
        metadata: metadata || {},
        resolved: false
      })
      .select()
      .single();

    if (alertInsert.error) {

      return Response.json({
        success: false,
        stage: "security_alerts_insert",
        error: alertInsert.error
      }, {
        status: 500
      });

    }

    if (
      severity === "critical" ||
      severity === "high"
    ) {

      const incidentInsert = await supabase
        .from("security_incidents")
        .insert({
          incident_type: alert_type,
          severity,
          user_id,
          ip_address: metadata?.ip || null,
          metadata: metadata || {},
          resolved: false
        })
        .select()
        .single();

      if (incidentInsert.error) {

        return Response.json({
          success: false,
          stage: "security_incidents_insert",
          error: incidentInsert.error
        }, {
          status: 500
        });

      }

    }

    return Response.json({
      success: true,
      alert_id: alertInsert.data.id,
      severity
    });

  } catch (error) {

    return Response.json({
      success: false,
      stage: "catch",
      error_message: String(error),
      error_object: error
    }, {
      status: 500
    });

  }

});