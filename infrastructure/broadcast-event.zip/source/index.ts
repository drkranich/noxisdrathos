import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const body = await req.json()

const {

eventType,

entityType,

entityId,

payload

} = body

if(

!eventType ||

!entityType ||

!entityId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

const allowedEvents = [

"content_updated",

"comment_created",

"user_typing",

"reaction_added"

]

if(

!allowedEvents.includes(

eventType

)

){

return new Response(

"Invalid event",

{

status:400

}

)

}

const safePayload =

JSON.stringify(

payload || {}

)

if(

safePayload.length > 5000

){

return new Response(

"Payload too large",

{

status:400

}

)

}

const {

error:insertError

}

= await supabase

.from(

"live_events"

)

.insert({

event_type:eventType,

actor_user:user.id,

entity_type:entityType,

entity_id:entityId,

payload

})

if(insertError){

return new Response(

JSON.stringify({

error:insertError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

return Response.json({

ok:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})