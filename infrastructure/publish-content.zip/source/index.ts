import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

const now =

new Date().toISOString()

const {

data:scheduled,

error:scheduledError

}

= await supabase

.from(

"content_schedule"

)

.select(`

id,

content_id,

publish_at

`)

.eq(

"published",

false

)

.lte(

"publish_at",

now

)

if(scheduledError){

return new Response(

JSON.stringify({

error:scheduledError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

for(

const item of scheduled || []

){

await supabase

.from(

"content"

)

.update({

published:true,

published_at:now

})

.eq(

"id",

item.content_id

)

await supabase

.from(

"content_schedule"

)

.update({

published:true

})

.eq(

"id",

item.id

)

}

return Response.json({

success:true

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})