import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const { count: totalAlerts } = await supabase
      .from("security_alerts")
      .select("*", {
        count: "exact",
        head: true
      });

    const { count: openIncidents } = await supabase
      .from("security_incidents")
      .select("*", {
        count: "exact",
        head: true
      })
      .eq("resolved", false);

    const { count: resolvedIncidents } = await supabase
      .from("security_incidents")
      .select("*", {
        count: "exact",
        head: true
      })
      .eq("resolved", true);

    const { data: latestAlerts } = await supabase
      .from("security_alerts")
      .select("*")
      .order("created_at", {
        ascending: false
      })
      .limit(10);

    const { data: latestThreats } = await supabase
      .from("threat_events")
      .select("*")
      .order("created_at", {
        ascending: false
      })
      .limit(10);

    return Response.json({

      success: true,

      dashboard: {

        total_alerts:
          totalAlerts || 0,

        open_incidents:
          openIncidents || 0,

        resolved_incidents:
          resolvedIncidents || 0,

        latest_alerts:
          latestAlerts || [],

        latest_threats:
          latestThreats || []

      }

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});