import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return Response.json({

enabled:false

})

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return Response.json({

enabled:false

})

}

const body = await req.json()

const {

featureKey,
tenantId

} = body

if(

!featureKey ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
FETCH FEATURE FLAG
==================================================
*/

const {

data:feature

}

= await supabase

.from(

"feature_flags"

)

.select(`

id,
key,
enabled,
premium_only,
rollout_percentage,
experiment_enabled

`)

.eq(

"key",

featureKey

)

.eq(

"tenant_id",

tenantId

)

.single()

if(

!feature ||

!feature.enabled

){

return Response.json({

enabled:false

})

}

/*
==================================================
USER OVERRIDES
==================================================
*/

const {

data:override

}

= await supabase

.from(

"user_feature_overrides"

)

.select(`

enabled

`)

.eq(

"user_id",

user.id

)

.eq(

"feature_flag_id",

feature.id

)

.maybeSingle()

if(override){

return Response.json({

enabled:

override.enabled,

source:

"user_override"

})

}

/*
==================================================
PREMIUM CHECK
==================================================
*/

if(feature.premium_only){

const {

data:subscription

}

= await supabase

.from(

"subscriptions"

)

.select(`

status

`)

.eq(

"user_id",

user.id

)

.eq(

"status",

"active"

)

.single()

if(!subscription){

return Response.json({

enabled:false,

source:"premium_required"

})

}

}

/*
==================================================
ROLLOUT PERCENTAGE
==================================================
*/

const rolloutPercentage =

feature.rollout_percentage || 100

const rolloutSeed =

parseInt(

user.id.replace(/\D/g,"").slice(0,6) || "1"

)

% 100

if(

rolloutSeed >

rolloutPercentage

){

return Response.json({

enabled:false,

source:"rollout_block"

})

}

/*
==================================================
EXPERIMENT SUPPORT
==================================================
*/

let assignedVariant = null

if(feature.experiment_enabled){

const {

data:assignment

}

= await supabase

.from(

"experiment_assignments"

)

.select(`

variant_id

`)

.eq(

"user_id",

user.id

)

.limit(1)

.maybeSingle()

assignedVariant =

assignment?.variant_id || null

}

/*
==================================================
RESOLUTION SNAPSHOT
==================================================
*/

await supabase

.from(

"feature_resolution_logs"

)

.insert({

tenant_id:tenantId,

user_id:user.id,

feature_key:featureKey,

resolved_enabled:true,

resolved_variant:assignedVariant

})

/*
==================================================
FINAL RESPONSE
==================================================
*/

return Response.json({

enabled:true,

variant:assignedVariant,

source:"feature_flag"

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})