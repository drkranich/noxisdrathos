import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return Response.json({

variant:null

})

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return Response.json({

variant:null

})

}

const body = await req.json()

const {

experimentKey,
tenantId

} = body

if(

!experimentKey ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
FETCH EXPERIMENT
==================================================
*/

const {

data:experiment

}

= await supabase

.from(

"experiments"

)

.select(`

id,
experiment_key,
status,
rollout_percentage

`)

.eq(

"experiment_key",

experimentKey

)

.eq(

"tenant_id",

tenantId

)

.eq(

"status",

"running"

)

.single()

if(!experiment){

return Response.json({

variant:null

})

}

/*
==================================================
CHECK EXISTING ASSIGNMENT
==================================================
*/

const {

data:existingAssignment

}

= await supabase

.from(

"experiment_assignments"

)

.select(`

variant_id

`)

.eq(

"user_id",

user.id

)

.eq(

"experiment_id",

experiment.id

)

.single()

if(existingAssignment){

const {

data:existingVariant

}

= await supabase

.from(

"experiment_variants"

)

.select(`

id,
variant_key,
name

`)

.eq(

"id",

existingAssignment.variant_id

)

.single()

return Response.json({

variant:existingVariant

})

}

/*
==================================================
FETCH VARIANTS
==================================================
*/

const {

data:variants

}

= await supabase

.from(

"experiment_variants"

)

.select(`

id,
variant_key,
name,
weight

`)

.eq(

"experiment_id",

experiment.id

)

.limit(20)

if(

!variants ||

variants.length === 0

){

return Response.json({

variant:null

})

}

/*
==================================================
ROLLOUT CHECK
==================================================
*/

const rolloutPercentage =

experiment.rollout_percentage || 100

const rolloutSeed =

parseInt(

user.id.replace(/\D/g,"").slice(0,6) || "1"

)

% 100

if(

rolloutSeed >

rolloutPercentage

){

return Response.json({

variant:null

})

}

/*
==================================================
DETERMINISTIC ASSIGNMENT
==================================================
*/

const totalWeight =

variants.reduce(

(sum,v)=>

sum + (v.weight || 1),

0

)

const seed =

parseInt(

user.id.replace(/\D/g,"").slice(0,8) || "1"

)

let cursor = 0

let assignedVariant = variants[0]

const normalizedSeed =

seed % totalWeight

for(

const variant of variants

){

cursor += variant.weight || 1

if(

normalizedSeed < cursor

){

assignedVariant = variant

break

}

}

/*
==================================================
PERSIST ASSIGNMENT
==================================================
*/

await supabase

.from(

"experiment_assignments"

)

.insert({

user_id:user.id,

tenant_id:tenantId,

experiment_id:experiment.id,

variant_id:assignedVariant.id

})

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

variant:{

id:assignedVariant.id,

variant_key:

assignedVariant.variant_key,

name:

assignedVariant.name

}

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})