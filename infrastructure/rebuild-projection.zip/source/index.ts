import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    await supabase
      .from("content_read_models")
      .delete()
      .neq("id", "00000000-0000-0000-0000-000000000000");

    const { data: contents, error } = await supabase
      .from("content")
      .select("*");

    if (error) {
      throw error;
    }

    let rebuilt = 0;

    for (const item of contents || []) {

      await supabase
        .from("content_read_models")
        .insert({

          content_id: item.id,

          title: item.title,

          content_type: item.content_type,

          visibility: item.visibility,

          access_level: item.access_level,

          author_id: item.author_id,

          published: item.published,

          published_at: item.published_at,

          projection_version: 1,

          updated_at: new Date().toISOString()

        });

      rebuilt++;

    }

    return Response.json({

      success: true,

      rebuilt

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});