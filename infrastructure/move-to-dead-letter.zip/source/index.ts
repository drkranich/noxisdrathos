import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {

      scheduled_job_id,
      failure_reason

    } = body;

    const { data: job, error } = await supabase
      .from("scheduled_jobs")
      .select("*")
      .eq("id", scheduled_job_id)
      .single();

    if (error || !job) {

      return Response.json({
        success: false,
        error: "job_not_found"
      }, {
        status: 404
      });

    }

    await supabase
      .from("dead_letter_jobs")
      .insert({

        job_name: job.job_type,

        edge_function:
          job.payload_json?.edge_function ||
          "unknown",

        payload: job.payload_json,

        failure_reason:
          failure_reason ||
          "manual_failure"

      });

    await supabase
      .from("queue_failures")
      .insert({

        queue_name: "default",

        scheduled_job_id,

        failure_reason:
          failure_reason ||
          "manual_failure"

      });

    await supabase
      .from("scheduled_jobs")
      .update({

        status: "failed",

        executed_at:
          new Date().toISOString()

      })
      .eq("id", scheduled_job_id);

    return Response.json({

      success: true,

      moved_to_dead_letter: true,

      job_id: scheduled_job_id

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});