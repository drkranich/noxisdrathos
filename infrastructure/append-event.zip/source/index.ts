import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const body = await req.json();

    const {
      aggregate_type,
      aggregate_id,
      event_type,
      event_data
    } = body;

    const { data, error } = await supabase
      .from("event_store")
      .insert({

        aggregate_type,

        aggregate_id,

        event_type,

        event_data: event_data || {},

        event_version: 1

      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    await supabase
      .from("domain_events")
      .insert({

        aggregate_type,

        aggregate_id,

        event_type,

        payload: event_data || {}

      });

    return Response.json({

      success: true,

      event_id: data.id,

      event_type

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});