import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

/*
==================================================
WORKER AUTHORIZATION
==================================================
*/

const workerSecret = req.headers.get(

"x-worker-secret"

)

if(

workerSecret !==

Deno.env.get(

"WORKER_SECRET"

)

){

return new Response(

"Forbidden",

{

status:403

}

)

}

/*
==================================================
REQUEST BODY
==================================================
*/

const body = await req.json()

const {

experimentId,
tenantId,
enableAutoRollout,
enableAIOptimization

} = body

if(

!experimentId ||

!tenantId

){

return new Response(

"Missing fields",

{

status:400

}

)

}

/*
==================================================
SUPABASE CLIENT
==================================================
*/

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_SERVICE_ROLE_KEY"

)!

)

/*
==================================================
FETCH EXPERIMENT EVENTS
==================================================
*/

const {

data:events,

error:eventsError

}

= await supabase

.from(

"experiment_events"

)

.select(`

variant,
event_type,
user_id

`)

.eq(

"experiment_id",

experimentId

)

.eq(

"tenant_id",

tenantId

)

if(eventsError){

return new Response(

JSON.stringify({

error:eventsError.message

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

/*
==================================================
AGGREGATION
==================================================
*/

const aggregation = {}

for(

const event of events || []

){

const variant = event.variant

if(!aggregation[variant]){

aggregation[variant] = {

views:0,

clicks:0,

conversions:0,

unique_users:new Set(),

conversion_rate:0,

ctr:0,

bayesian_score:0,

chi_square_score:0,

p_value:1

}

}

if(

event.user_id

){

aggregation[variant]

.unique_users

.add(

event.user_id

)

}

if(

event.event_type === "view"

){

aggregation[variant].views++

}

if(

event.event_type === "click"

){

aggregation[variant].clicks++

}

if(

event.event_type === "conversion"

){

aggregation[variant].conversions++

}

}

/*
==================================================
STATISTICS COMPUTATION
==================================================
*/

let winnerVariant = null

let highestScore = 0

for(

const variant in aggregation

){

const stats = aggregation[variant]

stats.unique_users =

stats.unique_users.size

stats.conversion_rate =

stats.views > 0

? stats.conversions / stats.views

: 0

stats.ctr =

stats.views > 0

? stats.clicks / stats.views

: 0

/*
-----------------------------------
BAYESIAN SCORE
-----------------------------------
*/

stats.bayesian_score =

(

stats.conversions + 1

)

/

(

stats.views + 2

)

/*
-----------------------------------
CHI-SQUARE APPROXIMATION
-----------------------------------
*/

stats.chi_square_score =

stats.views > 0

?

(

Math.pow(

stats.conversions -

(stats.views * 0.5),

2

)

/

stats.views

)

: 0

/*
-----------------------------------
P-VALUE APPROXIMATION
-----------------------------------
*/

stats.p_value =

1 -

Math.min(

stats.bayesian_score,

0.99

)

/*
-----------------------------------
WINNER COMPUTATION
-----------------------------------
*/

const finalScore =

stats.bayesian_score *

0.7 +

stats.conversion_rate *

0.3

if(

finalScore >

highestScore

){

highestScore = finalScore

winnerVariant = variant

}

}

/*
==================================================
AI-DRIVEN OPTIMIZATION
==================================================
*/

let aiRecommendation = null

if(

enableAIOptimization

){

if(

highestScore > 0.25

){

aiRecommendation =

`Strong winning variant detected: ${winnerVariant}. Consider global rollout.`

}

else if(

highestScore > 0.15

){

aiRecommendation =

`Variant ${winnerVariant} is performing better, but requires more traffic.`

}

else{

aiRecommendation =

`No statistically strong winner yet. Continue experiment.`

}

}

/*
==================================================
AUTO ROLLOUT
==================================================
*/

if(

enableAutoRollout &&

winnerVariant &&

highestScore > 0.2

){

await supabase

.from(

"feature_flags"

)

.update({

active_variant:winnerVariant,

auto_rolled_out:true,

rolled_out_at:

new Date()

.toISOString()

})

.eq(

"experiment_id",

experimentId

)

.eq(

"tenant_id",

tenantId

)

}

/*
==================================================
SAVE RESULTS SNAPSHOT
==================================================
*/

await supabase

.from(

"experiment_results"

)

.insert({

tenant_id:tenantId,

experiment_id:experimentId,

aggregation,

winner_variant:winnerVariant,

winner_score:highestScore,

ai_recommendation:aiRecommendation,

computed_at:

new Date()

.toISOString()

})

/*
==================================================
RESPONSE
==================================================
*/

return Response.json({

success:true,

tenantId,

winner:winnerVariant,

winnerScore:highestScore,

aggregation,

aiRecommendation

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})