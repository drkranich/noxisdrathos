import { serve }

from "https://deno.land/std/http/server.ts"

import { createClient }

from "https://esm.sh/@supabase/supabase-js"

serve(async(req)=>{

try{

const authorization =

req.headers.get("Authorization")

if(

!authorization ||

!authorization.startsWith(

"Bearer "

)

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const token = authorization.replace(

"Bearer ",

""

)

const supabase = createClient(

Deno.env.get(

"SUPABASE_URL"

)!,

Deno.env.get(

"SUPABASE_ANON_KEY"

)!,

{

global:{

headers:{

Authorization:

`Bearer ${token}`

}

}

}

)

const {

data:{ user },

error:userError

}

= await supabase.auth.getUser()

if(

userError ||

!user

){

return new Response(

"Unauthorized",

{

status:401

}

)

}

const body = await req.json()

const {

resourceType

} = body

const {

data:subscription,

error:subscriptionError

}

= await supabase

.from(

"subscriptions"

)

.select(

"status, renews_at"

)

.eq(

"user_id",

user.id

)

.single()

if(

subscriptionError ||

!subscription ||

subscription.status !== "active"

){

return new Response(

"No access",

{

status:403

}

)

}

const {

data:blocked

}

= await supabase

.from(

"revoked_access"

)

.select(

"id"

)

.eq(

"user_id",

user.id

)

.limit(1)

if(

blocked &&

blocked.length > 0

){

return new Response(

"Revoked",

{

status:403

}

)

}

return Response.json({

allowed:true,

resourceType,

subscriptionStatus:

subscription.status,

renewsAt:

subscription.renews_at

})

}

catch(error){

return new Response(

JSON.stringify({

error:String(error)

}),

{

status:500,

headers:{

"Content-Type":

"application/json"

}

}

)

}

})