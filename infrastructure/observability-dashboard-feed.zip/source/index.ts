import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {

    const { count: pendingJobs } = await supabase
      .from("scheduled_jobs")
      .select("*", {
        count: "exact",
        head: true
      })
      .eq("status", "pending");

    const { count: failedJobs } = await supabase
      .from("dead_letter_jobs")
      .select("*", {
        count: "exact",
        head: true
      });

    const { count: activePolicies } = await supabase
      .from("access_policies")
      .select("*", {
        count: "exact",
        head: true
      });

    const { data: latestHealth } = await supabase
      .from("service_health")
      .select("*")
      .order("checked_at", {
        ascending: false
      })
      .limit(5);

    const { data: latestErrors } = await supabase
      .from("error_events")
      .select("*")
      .order("created_at", {
        ascending: false
      })
      .limit(10);

    const { data: latestSnapshots } = await supabase
      .from("performance_snapshots")
      .select("*")
      .order("created_at", {
        ascending: false
      })
      .limit(5);

    return Response.json({

      success: true,

      dashboard: {

        pending_jobs:
          pendingJobs || 0,

        failed_jobs:
          failedJobs || 0,

        active_policies:
          activePolicies || 0,

        health:
          latestHealth || [],

        recent_errors:
          latestErrors || [],

        snapshots:
          latestSnapshots || []

      }

    });

  } catch (error) {

    return Response.json({

      success: false,

      error: String(error)

    }, {

      status: 500

    });

  }

});